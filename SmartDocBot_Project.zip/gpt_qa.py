import openai

def generate_answer(question, context_chunks):
    context = "\n".join(context_chunks)
    prompt = f"Answer the question based on this context:\n{context}\n\nQuestion: {question}"
    response = openai.ChatCompletion.create(
        model="gpt-3.5-turbo",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content.strip()