# SmartDocBot – GenAI PDF Q&A Assistant

SmartDocBot is an AI-powered assistant that answers questions based on PDF documents using Retrieval-Augmented Generation (RAG).

## Features

- Upload PDF files and extract clean text using PyMuPDF
- Vectorize document content with OpenAI Embeddings (`text-embedding-ada-002`)
- Store vectors in FAISS for fast similarity search
- Use GPT (gpt-3.5-turbo) to generate answers based on relevant context
- Built with FastAPI for easy RESTful API

## Installation

```bash
pip install -r requirements.txt
uvicorn main:app --reload
```

## Usage

1. Upload a PDF to `/upload`
2. Ask questions on `/ask`

## Author

**Liwaa Hosh** – Software Engineer passionate about GenAI  
[LinkedIn](https://www.linkedin.com/in/liwaa-hosh-4101711b0) | [GitHub](https://github.com/LiwaaCoder)