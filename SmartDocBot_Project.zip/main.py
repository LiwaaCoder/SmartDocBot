from fastapi import FastAPI, UploadFile, File
from pdf_parser import extract_text_from_pdf
from vector_store import build_vector_store, search_similar_chunks
from gpt_qa import generate_answer

app = FastAPI()
vector_index = None
text_chunks = []

@app.post("/upload")
async def upload(file: UploadFile = File(...)):
    global vector_index, text_chunks
    content = await file.read()
    text_chunks = extract_text_from_pdf(content)
    vector_index = build_vector_store(text_chunks)
    return {"message": "PDF processed successfully"}

@app.post("/ask")
async def ask(question: str):
    context = search_similar_chunks(question, text_chunks, vector_index)
    answer = generate_answer(question, context)
    return {"answer": answer}