import fitz  # PyMuPDF

def extract_text_from_pdf(file_bytes):
    doc = fitz.open(stream=file_bytes, filetype="pdf")
    chunks = []
    for page in doc:
        text = page.get_text()
        chunks.extend(text.split("\n\n"))
    return [c.strip() for c in chunks if c.strip()]