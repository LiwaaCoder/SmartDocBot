import openai
import faiss
import numpy as np

def get_embedding(text):
    response = openai.Embedding.create(input=[text], model="text-embedding-ada-002")
    return response["data"][0]["embedding"]

def build_vector_store(chunks):
    vectors = [get_embedding(c) for c in chunks]
    dim = len(vectors[0])
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(vectors).astype("float32"))
    return index

def search_similar_chunks(question, chunks, index, k=5):
    q_vector = get_embedding(question)
    D, I = index.search(np.array([q_vector]).astype("float32"), k)
    return [chunks[i] for i in I[0]]